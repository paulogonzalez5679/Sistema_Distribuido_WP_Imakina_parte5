<?php
/**
 * @var $course_id
 * @var $item_id
 */

STM_LMS_Templates::show_lms_template('global/buy-button/mixed', compact('course_id', 'item_id'));