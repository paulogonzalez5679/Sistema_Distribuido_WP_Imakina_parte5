<?php if (!defined('ABSPATH')) exit; //Exit if accessed directly ?>

<?php
/**
 * @var $post_id
 * @var $item_id
 */

$q = new WP_Query(array(
    'posts_per_page' => 1,
    'post_type' => 'stm-assignments',
    'post__in' => array($item_id)
));

$actual_link = STM_LMS_Assignments::get_current_url();

if ($q->have_posts()): ?>
    <div class="stm-lms-course__assignment">
        <?php while ($q->have_posts()): $q->the_post(); ?>

            <div class="clearfix">
                <?php the_content(); ?>
            </div>

            <a href="<?php echo esc_url(add_query_arg(array('start_assignment' => $item_id, 'course_id' => $post_id), $actual_link )); ?>"
               class="btn btn-default start_assignment">
                <?php esc_html_e('Start now', 'masterstudy-lms-learning-management-system-pro'); ?>
            </a>

        <?php endwhile; ?>
    </div>


 
     <div class="space" style="height: 32px;"></div>
<?php if ( have_rows( 'enlaces_adicioanles' ) ) : ?>
    <div class="row tituloExtras">
        <h2>Enlaces Adicionales</h2> 
    </div>

        <?php if ( have_rows( 'enlaces_adicioanles' ) ) : ?>
            <?php while ( have_rows( 'enlaces_adicioanles' ) ) : the_row(); ?>
                <?php $Imagen = get_sub_field( 'Imagen' ); ?>
                <?php if ( $Imagen ) : ?>
                    <img src="<?php echo esc_url( $Imagen['url'] ); ?>" alt="<?php echo esc_attr( $Imagen['alt'] ); ?>" />
                <?php endif; ?>
                <a href="<?php the_sub_field( 'url' ); ?>" target="_Blank"><?php the_sub_field( 'titulo_de_item' ); ?></a>
            <?php endwhile; ?>
        <?php else : ?>
            <?php // no rows found ?>
        <?php endif; ?>
<?php else : ?>
<?php // no rows found ?>
<?php endif; ?>


<?php endif;