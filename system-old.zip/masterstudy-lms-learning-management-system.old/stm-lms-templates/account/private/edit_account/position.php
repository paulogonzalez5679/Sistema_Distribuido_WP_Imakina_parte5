<div class="row">

    <div class="col-md-12">
        <div class="form-group">
            <label class="heading_font"><?php esc_html_e('Position', 'masterstudy-lms-learning-management-system'); ?></label>
            <input v-model="data.meta.position"
                   class="form-control"
                   placeholder="<?php esc_html_e('Enter your position', 'masterstudy-lms-learning-management-system') ?>"/>
        </div>
    </div>
</div>