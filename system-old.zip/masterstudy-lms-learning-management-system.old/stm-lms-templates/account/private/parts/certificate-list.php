<?php
/**
 * @var $current_user
 */

do_action('stm_lms_certificate_list', $current_user);