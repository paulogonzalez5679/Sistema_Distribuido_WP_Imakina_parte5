<?php
/**
 * @var $current_user
 */

do_action('stm_lms_my_certificates_btn');