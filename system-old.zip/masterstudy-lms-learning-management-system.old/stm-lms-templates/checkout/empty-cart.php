<h3 class="stm_lms_empty_cart">
	<?php printf(__('Cart is empty<span>,</span> <a href="%s">add Courses</a>', 'masterstudy-lms-learning-management-system'), STM_LMS_Course::courses_page_url()); ?>
</h3>