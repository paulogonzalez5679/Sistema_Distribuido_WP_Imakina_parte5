<div class="modal fade stm-lms-modal-become-instructor" tabindex="-1" role="dialog" aria-labelledby="stm-lms-modal-become-instructor">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-body">
                <?php STM_LMS_Templates::show_lms_template('account/become_instructor'); ?>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    stm_lms_become_instructor();
</script>