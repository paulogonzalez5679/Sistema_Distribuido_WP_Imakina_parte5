"use strict";

(function ($) {
  $(document).ready(function () {
    $('body').addClass('lesson-locked');
  });
})(jQuery);