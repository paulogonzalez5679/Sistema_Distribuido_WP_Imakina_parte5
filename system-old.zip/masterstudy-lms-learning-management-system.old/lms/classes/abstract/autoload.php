<?php
require_once STM_LMS_PATH."/lms/classes/abstract/StmSettingsApi.php";
require_once STM_LMS_PATH."/lms/classes/abstract/StmPaymentGateway.php";

