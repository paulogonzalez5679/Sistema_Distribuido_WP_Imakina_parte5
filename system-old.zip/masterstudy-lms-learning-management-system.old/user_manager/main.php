<?php

require_once STM_LMS_PATH . '/user_manager/UserManager.Interface.php';
require_once STM_LMS_PATH . '/user_manager/UserManager.Courses.php';
require_once STM_LMS_PATH . '/user_manager/UserManager.Course.php';
require_once STM_LMS_PATH . '/user_manager/UserManager.CourseUser.php';
require_once STM_LMS_PATH . '/user_manager/UserManager.AddUser.php';
require_once STM_LMS_PATH . '/user_manager/UserManager.UserAssignments.php';
require_once STM_LMS_PATH . '/user_manager/UserManager.UserQuiz.php';